<?php
$host = 'localhost';
$dbname = 'NOME DO SEU BANCO DE DADOS';
$user = 'USUARIO DO SEU BANCO DE DADOS';
$pass = 'SENHA DO SEU BANCO DE DADOS';

try {
  $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  die("Erro na conexão: " . $e->getMessage());
}
