<?php
$host = 'localhost';
$dbname = 'u544804289_devocional';
$user = 'u544804289_devocional';
$pass = ';5rE+YSb*1xS';

try {
  $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  die("Erro na conexão: " . $e->getMessage());
}
