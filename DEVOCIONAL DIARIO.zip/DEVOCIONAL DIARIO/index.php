<?php
include 'includes/conexao.php';

// Captura a URL base do site automaticamente
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$siteUrl = $protocol . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
$siteUrl = rtrim($siteUrl, '/\\'); // Remove barras no final

$dataHoje = date('Ymd');
$dataFormatada = date('d/m/Y');
srand($dataHoje);

$sql = $pdo->query("SELECT COUNT(*) FROM verses");
$total = $sql->fetchColumn();
$id = rand(1, $total);

$sql = $pdo->prepare("SELECT v.text, v.chapter, v.verse, b.name as livro 
                      FROM verses v 
                      JOIN books b ON v.book = b.id 
                      WHERE v.id = ?");
$sql->execute([$id]);
$versiculo = $sql->fetch();

// Texto formatado para compartilhamento
$shareText = "✨ *DEVOCIONAL* ✨\n\n".
             "\"".$versiculo['text']."\"\n\n".
             "📖 *".$versiculo['livro']." ".$versiculo['chapter'].":".$versiculo['verse']."*\n\n".
             "💭 *Reflexão do Dia:* Que esta palavra possa abençoar seu coração hoje!\n\n".
             "🔗 ".$siteUrl."\n\n";
           

// Texto para compartilhamento como imagem
$shareImageText = "✨ DEVOCIONAL DO DIA ✨\n\n".
                  "\"".$versiculo['text']."\"\n\n".
                  "📖 ".$versiculo['livro']." ".$versiculo['chapter'].":".$versiculo['verse']."\n\n".
                  "💭 Reflexão do Dia: Que esta palavra possa abençoar seu coração hoje!\n\n".
                  "🔗 ".$siteUrl;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Devocional Diário</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta property="og:title" content="Devocional do Dia - <?= $dataFormatada ?>">
  <meta property="og:description" content="<?= $versiculo['text'] ?> - <?= $versiculo['livro'] ?> <?= $versiculo['chapter'] ?>:<?= $versiculo['verse'] ?>">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
  <link rel="manifest" href="manifest.json">
  <meta name="theme-color" content="#317EFB">

  <style>
    :root {
      --primary: #8D72E1;
      --secondary: #6C4AB6;
      --accent: #B9E0FF;
      --text: #FFFFFF;
      --bg: rgba(0, 0, 0, 0.7);
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Montserrat', sans-serif;
      background: url('https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?q=80&w=1000') center/cover no-repeat fixed;
      color: var(--text);
      margin: 0;
      padding: 20px;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      text-align: center;
    }

    .devotional-card {
      background: var(--bg);
      border-radius: 20px;
      padding: 40px 30px;
      width: 100%;
      max-width: 700px;
      margin: 20px auto;
      box-shadow: 0 15px 30px rgba(0,0,0,0.5);
      position: relative;
      overflow: hidden;
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      border: 1px solid rgba(255,255,255,0.1);
    }

    .devotional-card::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 8px;
      background: linear-gradient(90deg, var(--primary), var(--secondary));
    }

    h1 {
      font-family: 'Playfair Display', serif;
      font-size: 2.2rem;
      margin-bottom: 10px;
      color: var(--accent);
      position: relative;
      display: inline-block;
    }

    h1::after {
      content: "";
      position: absolute;
      bottom: -8px;
      left: 50%;
      transform: translateX(-50%);
      width: 60px;
      height: 3px;
      background: var(--secondary);
      border-radius: 3px;
    }

    .date {
      font-size: 1rem;
      color: rgba(255,255,255,0.8);
      margin-bottom: 30px;
      display: block;
      font-weight: 600;
    }

    .verse-text {
      font-size: 1.4rem;
      line-height: 1.8;
      margin: 30px 0;
      position: relative;
      padding: 0 20px;
      font-style: italic;
      color: var(--text);
    }

    .verse-text::before,
    .verse-text::after {
      content: '"';
      font-size: 3rem;
      color: var(--accent);
      position: absolute;
      opacity: 0.5;
    }

    .verse-text::before {
      top: -20px;
      left: -5px;
    }

    .verse-text::after {
      bottom: -40px;
      right: -5px;
    }

    .verse-reference {
      display: inline-block;
      background: rgba(255,255,255,0.1);
      padding: 10px 20px;
      border-radius: 30px;
      font-weight: 600;
      color: var(--accent);
      margin: 20px 0;
      font-size: 1.1rem;
      border: 1px solid rgba(255,255,255,0.2);
    }

    .actions {
      display: flex;
      gap: 15px;
      justify-content: center;
      flex-wrap: wrap;
      margin-top: 40px;
    }

    .btn {
      background: linear-gradient(135deg, var(--primary), var(--secondary));
      color: white;
      padding: 15px 25px;
      text-decoration: none;
      border-radius: 30px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      font-size: 1rem;
      transition: all 0.3s ease;
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
      border: none;
      cursor: pointer;
      min-width: 200px;
    }

    .btn:hover {
      transform: translateY(-3px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.4);
    }

    .btn i {
      margin-right: 8px;
      font-size: 1.2rem;
    }

    .btn-whatsapp {
      background: linear-gradient(135deg, #25D366, #128C7E);
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    }

    .btn-whatsapp:hover {
      box-shadow: 0 8px 20px rgba(0,0,0,0.4);
    }

    .btn-message {
      background: linear-gradient(135deg, #3b5998, #4267B2);
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    }
    
    .btn-message:hover {
      box-shadow: 0 8px 20px rgba(0,0,0,0.4);
    }

    .reflection {
      font-size: 1.1rem;
      color: rgba(255,255,255,0.9);
      margin: 25px 0;
      padding: 20px;
      background: rgba(185, 224, 255, 0.1);
      border-radius: 15px;
      border-left: 4px solid var(--accent);
    }

    @media (max-width: 768px) {
      .devotional-card {
        padding: 30px 20px;
      }
      
      h1 {
        font-size: 1.8rem;
      }
      
      .verse-text {
        font-size: 1.2rem;
        padding: 0 15px;
      }
      
      .actions {
        flex-direction: column;
        align-items: center;
      }
      
      .btn {
        width: 100%;
      }
    }
  </style>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
  <div class="devotional-card">
    <h1>Devocional do Dia</h1>
    <span class="date"><?= $dataFormatada ?></span>

    <p class="verse-text"><?= $versiculo['text'] ?></p>
    
   <span class="verse-reference">
  <i class="fas fa-book"></i> 
  <a href="https://nepster.xyz/Biblia/index.php?pesquisa=<?= 
      urlencode($versiculo['livro'].' '.$versiculo['chapter'].' '.$versiculo['verse']) 
  ?>" 
     target="_blank" 
     style="color: inherit; text-decoration: none;">
    <?= $versiculo['livro'] ?> <?= $versiculo['chapter'] ?>:<?= $versiculo['verse'] ?>
  </a>
</span>
    
    <div class="reflection">
      <strong><i class="fas fa-lightbulb"></i> Reflexão:</strong> Como esta palavra pode transformar seu dia hoje?
    </div>
    
    <div class="actions">
      <a href="https://wa.me/?text=<?= urlencode($shareText) ?>" class="btn btn-message">
        <i class="fas fa-share-alt"></i> Compartilhar Mensagem
      </a>
      <a href="#" class="btn btn-whatsapp" id="shareImageBtn">
        <i class="fab fa-whatsapp"></i> Compartilhar Imagem
      </a>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
  <script>
    document.getElementById('shareImageBtn').addEventListener('click', function(e) {
      e.preventDefault();
      
      const originalText = this.innerHTML;
      this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Preparando imagem...';
      
      // Criar um elemento temporário para a imagem
      const tempDiv = document.createElement('div');
      tempDiv.style.position = 'absolute';
      tempDiv.style.left = '-9999px';
      tempDiv.style.width = '600px';
      tempDiv.style.padding = '40px';
      tempDiv.style.background = 'rgba(0, 0, 0, 0.8)';
      tempDiv.style.color = 'white';
      tempDiv.style.borderRadius = '15px';
      tempDiv.style.fontFamily = "'Playfair Display', serif";
      tempDiv.style.textAlign = 'center';
      
      // Conteúdo da imagem
      // Dentro do script, modifique a linha que gera a referência na imagem para:
tempDiv.innerHTML = `
  <h1 style="font-size: 2rem; color: #B9E0FF; margin-bottom: 15px;">Devocional do Dia</h1>
  <p style="font-size: 1.5rem; font-style: italic; margin: 30px 0; line-height: 1.6;">"<?= $versiculo['text'] ?>"</p>
  <div style="font-size: 1.2rem; color: #B9E0FF; margin-top: 30px; font-weight: bold;">
    <a href="https://nepster.xyz/Biblia/index.php?pesquisa=<?= 
        urlencode($versiculo['livro'].' '.$versiculo['chapter'].' '.$versiculo['verse']) 
    ?>" 
       target="_blank" 
       style="color: inherit; text-decoration: none;">
      <?= $versiculo['livro'] ?> <?= $versiculo['chapter'] ?>:<?= $versiculo['verse'] ?>
    </a>
  </div>
`;
      
      document.body.appendChild(tempDiv);
      
      html2canvas(tempDiv, {
        scale: 2,
        backgroundColor: null,
        logging: true,
        useCORS: true
      }).then(canvas => {
        document.body.removeChild(tempDiv);
        this.innerHTML = originalText;
        
        // Converter para blob
        canvas.toBlob(function(blob) {
          if (navigator.canShare && navigator.canShare({ files: [new File([blob], 'devocional.png', { type: 'image/png' })] })) {
            navigator.share({
              files: [new File([blob], 'devocional-<?= $dataFormatada ?>.png', { type: 'image/png' })],
              title: 'Devocional do Dia',
              text: '<?= $versiculo["livro"] ?> <?= $versiculo["chapter"] ?>:<?= $versiculo["verse"] ?>'
            }).catch(err => {
              console.error('Erro ao compartilhar:', err);
              openImageAndWhatsApp(canvas);
            });
          } else {
            openImageAndWhatsApp(canvas);
          }
        }, 'image/png');
      }).catch(err => {
        console.error('Erro ao gerar imagem:', err);
        this.innerHTML = originalText;
        alert('Erro ao gerar imagem. Por favor, tente novamente.');
      });
    });
    
    function openImageAndWhatsApp(canvas) {
      const imageUrl = canvas.toDataURL('image/png');
      const win = window.open();
      win.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Devocional do Dia</title>
          <style>
            body { 
              margin: 0; 
              padding: 20px; 
              background: #222; 
              display: flex; 
              flex-direction: column; 
              align-items: center; 
              justify-content: center; 
              min-height: 100vh; 
              font-family: Arial, sans-serif;
            }
            img { 
              max-width: 100%; 
              height: auto; 
              border-radius: 10px; 
              margin-bottom: 20px;
            }
            a {
              display: inline-block;
              background: #25D366;
              color: white;
              padding: 12px 24px;
              border-radius: 30px;
              text-decoration: none;
              font-weight: bold;
              margin-top: 20px;
            }
          </style>
        </head>
        <body>
          <img src="${imageUrl}" alt="Devocional do Dia">
          <a href="https://wa.me/?text=<?= urlencode($shareImageText) ?>" target="_blank">Compartilhar no WhatsApp</a>
          <p style="color: white; margin-top: 20px;">Clique com o botão direito na imagem para salvar</p>
        </body>
        </html>
      `);
    }
  </script>
  
  
  
  
  
  
  
  
  
  
  
<!-- Popup de instalação PWA -->
<style>
  #install-popup {
    position: fixed;
    top: 5px;
    left: 5px;
    right: 5px;
    background: rgba(0, 0, 0, 0.85);
    color: white;
    padding: 15px 20px;
    border-radius: 10px;
    display: none;
    z-index: 9999;
    font-family: sans-serif;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    text-align: center;
  }

  #btn-install {
    margin-top: 10px;
    padding: 8px 16px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }

  #btn-install:hover {
    background-color: #45a049;
  }
</style>

<div id="install-popup">
  <div>Adicione este app à sua tela inicial!</div>
  <button id="btn-install">Instalar</button>
</div>

<script>
  let deferredPrompt;

  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;

    const popup = document.getElementById('install-popup');
    popup.style.display = 'block';

    // Oculta após 5 segundos automaticamente
    setTimeout(() => {
      popup.style.display = 'none';
    }, 5000);

    document.getElementById('btn-install').addEventListener('click', () => {
      popup.style.display = 'none';
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then((choiceResult) => {
        if (choiceResult.outcome === 'accepted') {
          console.log('Usuário aceitou a instalação');
        } else {
          console.log('Usuário recusou a instalação');
        }
        deferredPrompt = null;
      });
    });
  });

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('service-worker.js')
      .then(() => console.log('Service Worker registrado com sucesso!'))
      .catch((err) => console.error('Erro ao registrar Service Worker:', err));
  }
</script>







<audio id="musicaFundo" loop muted autoplay>
  <source src="audio/fundo.mp3" type="audio/mp3">
</audio>

<!-- Botão ativador (visível só no PC) -->
<div id="ativaAudio" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; z-index:9999; cursor:pointer;">
  <div style="position:absolute; bottom:20px; left:50%; transform:translateX(-50%); background:#000a; color:white; padding:10px 20px; border-radius:10px;">
    🔊 Clique para ativar o som
  </div>
</div>

<script>
  const audio = document.getElementById('musicaFundo');
  const ativador = document.getElementById('ativaAudio');

  // Detecta se é um dispositivo móvel
  const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

  if (!isMobile) {
    // Somente mostra o botão se for PC
    ativador.style.display = 'block';
  } else {
    // Em celular, desbloqueia ao rolar, clicar ou tocar
    const desbloquearMobile = () => {
      if (audio.muted) {
        audio.muted = false;
        audio.play();
      }
      window.removeEventListener('touchstart', desbloquearMobile);
      window.removeEventListener('scroll', desbloquearMobile);
    };
    window.addEventListener('touchstart', desbloquearMobile, { once: true });
    window.addEventListener('scroll', desbloquearMobile, { once: true });
  }

  // Desbloqueia áudio ao clicar no botão (PC)
  ativador.addEventListener('click', () => {
    if (audio.muted) {
      audio.muted = false;
    }
    audio.play().then(() => {
      ativador.style.display = 'none';
    });
  });
</script>






</body>
</html>