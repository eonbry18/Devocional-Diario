const CACHE_NAME = 'devocional-cache-v2';
const OFFLINE_URL = '/devot/offline.html';
const urlsToCache = [
  '/devot/',
  '/devot/index.php',
  '/devot/logo.jpg',
  '/devot/manifest.json',
  '/devot/includes/conexao.php',
  '/devot/contador.php',
  '/devot/harp.html',
  '/devot/louvor.html',
  '/devot/style.css',
  '/devot/script.js'
];

// Instalação
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Cache aberto');
        return cache.addAll(urlsToCache)
          .then(() => self.skipWaiting());
      })
  );
});

// Ativação (limpeza de caches antigos)
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cache => {
          if (cache !== CACHE_NAME) {
            return caches.delete(cache);
          }
        })
      ).then(() => self.clients.claim())
    })
  );
});

// Estratégia de fetch (Cache First, com fallback para rede)
self.addEventListener('fetch', event => {
  // Ignora requisições que não são GET
  if (event.request.method !== 'GET') return;
  
  // Para navegação (HTML)
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .catch(() => caches.match('/devot/index.php'))
    );
    return;
  }

  // Para outros recursos
  event.respondWith(
    caches.match(event.request)
      .then(cachedResponse => {
        // Retorna do cache ou busca na rede
        return cachedResponse || fetch(event.request)
          .then(response => {
            // Faz cache de novas respostas
            return caches.open(CACHE_NAME)
              .then(cache => {
                cache.put(event.request, response.clone());
                return response;
              });
          })
          .catch(error => {
            // Fallback para páginas offline
            if (event.request.headers.get('accept').includes('text/html')) {
              return caches.match('/devot/index.php');
            }
          });
      })
  );
});