<?php
// salvar_imagem.php

// Recebe JSON do JS
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['image'])) {
    $img = $data['image'];
    $img = str_replace('data:image/png;base64,', '', $img);
    $img = str_replace(' ', '+', $img);
    $data = base64_decode($img);

    $filename = 'images/versiculos/versiculo_' . date('Ymd_His') . '.png';
    if(!is_dir('images/versiculos')){
        mkdir('images/versiculos', 0777, true);
    }

    file_put_contents($filename, $data);

    // Retorna URL pública da imagem
    // Ajuste a URL conforme seu domínio
    $url = 'https://seudominio.com/' . $filename;

    echo json_encode(['success' => true, 'url' => $url]);
    exit;
}

echo json_encode(['success' => false]);
